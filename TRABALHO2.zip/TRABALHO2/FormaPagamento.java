package TRABALHO2;

public class FormaPagamento {

    private String FormaPagamento;

    public FormaPagamento(String formaPagamento) {
        FormaPagamento = formaPagamento;
    }

    public String getFormaPagamento() {
        return FormaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        FormaPagamento = formaPagamento;
    }

    public String toString() {
        return FormaPagamento;
    }
}
