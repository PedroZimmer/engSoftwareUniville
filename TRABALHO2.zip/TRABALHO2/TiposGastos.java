package TRABALHO2;

public class TiposGastos {

    private String TipoGastos;

    public TiposGastos(String tipoGastos) {
        TipoGastos = tipoGastos;
    }

    public String getTipoGastos() {
        return TipoGastos;
    }

    public void setTipoGastos(String tipoGastos) {
        TipoGastos = tipoGastos;
    }

    public String toString() {
        return TipoGastos;
    }



}
