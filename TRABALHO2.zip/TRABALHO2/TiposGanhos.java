package TRABALHO2;

public class TiposGanhos {

    private String TipoGanhos;

    public TiposGanhos(String tipoGanhos) {
        TipoGanhos = tipoGanhos;
    }

    public String getTipoGanhos() {
        return TipoGanhos;
    }

    public void setTipoGanhos(String tipoGanhos) {
        TipoGanhos = tipoGanhos;
    }

    //toString
    public String toString() {
        return TipoGanhos;
    }

}
